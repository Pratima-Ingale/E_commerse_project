# Databricks notebook source
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType,DateType,TimestampType,FloatType

catalog_name = 'E_commerce'

# COMMAND ----------

df_bronze = spark.table(f"{catalog_name}.bronze.brz_brands")
df_bronze.show(10)

# COMMAND ----------

df_silver = df_bronze.withColumn('brand_name',F.trim(F.col('brand_name')))  # to remove the space after brand name eg., NovaWave in 2nd row
df_silver.show(10)

# COMMAND ----------

df_silver = df_silver.withColumn("brand_code", F.regexp_replace(F.col("brand_code"),r'[^A-Za-z0-9]','')) # in row 7 VOLT la @ hot te remove karun brand code alfa numeric banavala
df_silver.show(10)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC df_silver ->	Your PySpark DataFrame
# MAGIC
# MAGIC .withColumn() ->	Creates a new column or replaces an existing column
# MAGIC
# MAGIC "brand_code" ->	Column that you want to clean
# MAGIC
# MAGIC F ->	Alias for pyspark.sql.functions
# MAGIC
# MAGIC F.col("brand_code") ->	Selects the brand_code column
# MAGIC
# MAGIC F.regexp_replace() ->	Finds text matching a pattern and replaces it
# MAGIC
# MAGIC r -> Treat this text as a raw string
# MAGIC
# MAGIC ^ -> ^ means NOT when it is placed immediately after [.
# MAGIC
# MAGIC r'[^A-Za-z0-9]' ->	Pattern: anything other than letters A-Z/a-z and numbers 0-9
# MAGIC
# MAGIC '' ->	Replace matching characters with nothing, so they are removed

# COMMAND ----------

df_silver.select("category_code").distinct().show()

# COMMAND ----------

# Anomalies dictionary
anomalies = {
    "GROCERY" : "GRCY",
    "BOOKS" : "BKS" ,
    "TOYS" : "TOY"
}

df_silver = df_silver.replace(anomalies,subset="category_code")
df_silver.select("category_code").distinct().show()

# COMMAND ----------

# MAGIC %md
# MAGIC .replace() ->
# MAGIC Replace one value with another
# MAGIC
# MAGIC anomalies ->
# MAGIC The values you want to replace
# MAGIC
# MAGIC subset="category_code" ->	Apply the replacement only to category_code column

# COMMAND ----------

# write raw data to the silver layer (catalog:E_commerce , schema: silver, table: slv_brands)
df_silver.write.format("delta")\
    .mode("overwrite")\
        .option("mergeSchema","true")\
            .saveAsTable(f"{catalog_name}.silver.slv_brands")
            

# COMMAND ----------

# MAGIC %md
# MAGIC #Category

# COMMAND ----------

df_bronze = spark.table(f"{catalog_name}.bronze.brz_category")

df_bronze.show(10)

# COMMAND ----------

df_duplicate = df_bronze.groupBy("category_code").count().filter(F.col("count")>1)
display(df_duplicate)

# COMMAND ----------

df_silver = df_bronze.dropDuplicates(['category_code']) # remove duplicate which are present in the provided column
display(df_silver)

# COMMAND ----------

df_silver = df_silver.withColumn("category_code",F.upper(F.col("category_code")))
display(df_silver)

# COMMAND ----------

#Write raw data to the silver layer (catelog:E_commerce, schema:silver,table:slv_category)
df_silver.write.format("delta")\
    .mode("overwrite")\
        .option("mergeSchema","true")\
        .saveAsTable(f"{catalog_name}.silver.slv_category")

# COMMAND ----------

# MAGIC %md
# MAGIC #Products

# COMMAND ----------

# Read the raw data from the bronze layer (catelog:E_commerce, schema:bronze, table:brz_calender)
df_bronze = spark.read.table(f"{catalog_name}.bronze.brz_products")

# Get row and column count
row_count , column_count =df_bronze.count(),len(df_bronze.columns)

# Print the results
print(f"Row count: {row_count}")
print(f"Column count: {column_count}")


# COMMAND ----------

display(df_bronze.limit(5))

# COMMAND ----------

# MAGIC %md
# MAGIC Check weight_grams(contains 'g')

# COMMAND ----------

# Check weight_grams column
df_bronze.select("weight_grams").show(5,truncate = False)

# COMMAND ----------

# replace 'g' with ''
df_silver = df_bronze.withColumn(
    "weight_grams",
    F.regexp_replace(F.col("weight_grams"),"g","").cast(IntegerType())
)
df_silver.select("weight_grams").show(5,truncate = False)

# COMMAND ----------

# MAGIC %md
# MAGIC Check length_cm (comma instead of dot)

# COMMAND ----------

df_silver.select("length_cm").show()

# COMMAND ----------

# replace , with .
df_silver = df_silver.withColumn(
    "length_cm",
    F.regexp_replace(F.col("length_cm"),",",".").cast(FloatType())
)
df_silver.select("length_cm").show(5)


# COMMAND ----------

# MAGIC %md
# MAGIC category_code and brand_code are in lower case. we need to make it all upper case

# COMMAND ----------

df_silver.select("category_code","brand_code").show(2)

# COMMAND ----------

# Convert category_code and brand_code to upper case
df_silver = df_silver.withColumn(
    "category_code",
    F.upper(F.col("category_code"))
)
df_silver = df_silver.withColumn(
    "brand_code",
    F.upper(F.col("brand_code"))
)
df_silver.select("category_code","brand_code").show(2)


# COMMAND ----------

# MAGIC %md
# MAGIC Spelling mistakes in material column

# COMMAND ----------

df_silver.select("material").distinct().show()

# COMMAND ----------

# Fix spelling mistakes
df_silver = df_silver.withColumn(
    "material",
    F.when(F.col("material") == "Coton","Cotton")
     .when(F.col("material") == "Alumium","Aluminium")
     .when(F.col("material") == "Ruber","Rubber")
     .otherwise(F.col("material"))
)
df_silver.select("material").distinct().show()

# COMMAND ----------

# MAGIC %md
# MAGIC .when() is used to check a condition and give a value when that condition is true.
# MAGIC
# MAGIC .otherwise() means “if none of the .when() conditions are true,“keep the original value if no condition matched.”

# COMMAND ----------

# MAGIC %md
# MAGIC Negative values in rating_count

# COMMAND ----------

df_silver.filter(F.col('rating_count')<0).select("rating_count").show()

# COMMAND ----------

# Convert negative rating_count to positive
df_silver = df_silver.withColumn(
    "rating_count",
    F.when(F.col("rating_count").isNotNull(),F.abs(F.col("rating_count")))
    .otherwise(F.lit(0)) # if null,replace with 0

)

# COMMAND ----------

# Check final cleaned data

df_silver.select(
    "weight_grams",
    "length_cm",
    "category_code",
    "brand_code",
    "material",
    "rating_count"
).show(10, truncate=False)

# COMMAND ----------

# Write raw data to the silver layer (catalog:E_commerce,schema:silver,table:products)
df_silver.write.format("delta")\
    .mode("overwrite")\
        .option("mergeSchema","true")\
            .saveAsTable(f"{catalog_name}.silver.slv_products")

# COMMAND ----------

# MAGIC %md
# MAGIC # Customers
# MAGIC

# COMMAND ----------

# Read the raw data from the bronze table (E_commerce.bronze.brz_customers)

df_bronze = spark.read.table(f"{catalog_name}.bronze.brz_customer")

# Get row and column count
row_count ,column_count = df_bronze.count(),len(df_bronze.columns)

# Print the results
print(f"Row count: {row_count}")
print(f"Column count: {column_count}")

df_bronze.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Handle NULL values in customer_id column

# COMMAND ----------

null_count = df_bronze.filter(F.col("customar_id").isNull()).count()
null_count

# COMMAND ----------

# There are 300 null values in customer_id column. Display some of those
df_bronze.filter(F.col("customar_id").isNull()).show(3)

# COMMAND ----------

# Drop rows where 'customar_id' is null
df_silver = df_bronze.dropna(subset=["customar_id"])

#Get row count
row_count = df_silver.count()
print(f"Row count after droping null values: {row_count}")

# COMMAND ----------

# MAGIC %md
# MAGIC Handle NULL values in phone column

# COMMAND ----------

null_count = df_silver.filter(F.col("phone").isNull()).count()
print(f"Number of nulls in phone :{null_count}")

# COMMAND ----------

df_silver.filter(F.col("phone").isNull()).show(3)

# COMMAND ----------

### Fill  null values with 'Not Available'
df_silver = df_silver.fillna("Not Available",subset =["phone"])

# sanity check (If any nulls still exists)
df_silver.filter(F.col("phone").isNull()).show()

# COMMAND ----------

# Write raw data to silver layer (catalog : E_commerce,schema:silver,table:slv_customar)
df_silver.write.format("delta")\
    .mode("overwrite")\
        .option("mergeSchema","true")\
            .saveAsTable(f"{catalog_name}.silver.slv_customar")

# COMMAND ----------

# MAGIC %md
# MAGIC #Calender/Date

# COMMAND ----------

# Read the raw data from the bronze table(E_commerce.bronze.brz_calendar)
df_bronze = spark.read.table(f"{catalog_name}.bronze.brz_calender")

# Get row and column count
row_count,column_count =df_bronze.count(),len(df_bronze.columns)

# Print the results
print(f"Row count:{row_count}")
print(f"Column count:{column_count}")

df_bronze.show(3)

# COMMAND ----------

df_bronze.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC Converting String to Date

# COMMAND ----------

from pyspark.sql.functions import to_date,col

# Convert the string column to a date type
df_silver = df_bronze.withColumn(
    "date"
    ,to_date(col("date"),"dd-MM-yyyy")
)

# COMMAND ----------

df_silver.printSchema()
df_silver.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC Remove Duplicates

# COMMAND ----------

# Find duplicate rows in the DataFrame
duplicates = df_silver.groupBy('date').count().filter("count > 1")

# Show the duplicate rows
print("Total duplicated Rows: ", duplicates.count())
display(duplicates)

# COMMAND ----------

# Remove duplicate rows
df_silver = df_silver.dropDuplicates(['date'])

# Get row count
row_count = df_silver.count()

print("Rows After removing Duplicates: ", row_count)

# COMMAND ----------

# MAGIC %md
# MAGIC day_name normalize casing

# COMMAND ----------

# MAGIC %md
# MAGIC F.initcap()
# MAGIC
# MAGIC 👉 Capitalizes the first letter of each word.

# COMMAND ----------

# Capitalize first letter of each word in day_name
df_silver = df_silver.withColumn("day_name", F.initcap(F.col("day_name")))

df_silver.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC Convert negative week_of_year to positive

# COMMAND ----------

df_silver = df_silver.withColumn("week_of_year", F.abs(F.col("week_of_year")))  # Convert negative to positive

df_silver.show(3)

# COMMAND ----------

# MAGIC %md
# MAGIC Enhance quarter and week_of_year column

# COMMAND ----------

# MAGIC %md
# MAGIC F.lit()
# MAGIC
# MAGIC 👉 Adds a fixed/literal value.

# COMMAND ----------

df_silver = df_silver.withColumn("quarter", F.concat_ws("", F.concat(F.lit("Q"), F.col("quarter"), F.lit("-"), F.col("year"))))

df_silver = df_silver.withColumn("week_of_year", F.concat_ws("-", F.concat(F.lit("Week"), F.col("week_of_year"), F.lit("-"), F.col("year"))))

df_silver.show(3)

# COMMAND ----------

# MAGIC %md
# MAGIC Writing them as Q1-2026 and Week5-2026 is mainly for clarity and easy identification.

# COMMAND ----------

# Rename a column
df_silver = df_silver.withColumnRenamed("week_of_year","week")

# COMMAND ----------

# Write raw data to the silver layer (catalog : E_commerce,schema:silver,table:slv_calender)
df_silver.write.format("delta")\
    .mode("overwrite")\
        .option("mergeSchema","true")\
            .saveAsTable(f"{catalog_name}.silver.slv_calender")