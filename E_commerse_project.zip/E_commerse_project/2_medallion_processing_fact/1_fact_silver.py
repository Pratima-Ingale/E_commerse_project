# Databricks notebook source
from pyspark.sql.types import StructType,StructField,StringType,IntegerType,DateType,BooleanType
import pyspark.sql.functions as F

# COMMAND ----------

catalog_name = "E_commerce"

# COMMAND ----------

df = spark.table(f'{catalog_name}.bronze.brz_order_items')
df.show(5)   

# COMMAND ----------

df.printSchema()

# COMMAND ----------

