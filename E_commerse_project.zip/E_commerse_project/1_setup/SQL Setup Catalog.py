# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE CATALOG IF NOT EXISTS E_commerce ;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC USE CATALOG E_commerce ;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE SCHEMA IF NOT EXISTS E_commerce.bronze ;
# MAGIC CREATE SCHEMA IF NOT EXISTS E_commerce.silver ;
# MAGIC CREATE SCHEMA IF NOT EXISTS E_commerce.gold ;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SHOW DATABASES FROM E_commerce;

# COMMAND ----------

# MAGIC %md
# MAGIC if you made any mistake in the project you can delete everything by executing following command
# MAGIC
# MAGIC %sql
# MAGIC
# MAGIC DROP CATALOG IF E_commerce CASCADE ;